function accept(element){
    document.querySelector('#cookie').remove();
}

function fToCel(valNum){
    return Math.round((valNum-32)/1.8);
}

function cToFar(valNum){
    return Math.round((valNum*1.8)+32);
    }
function convert(element){
    console.log(element.value);
    var temps=document.querySelectorAll(".hot, .cold");
    for(var i=0;i<temps.length;i++){
        console.log(temps[i]);
        temp=temps[i].innerText;
        console.log(temp);
        if(element.value=="celcius"){
            temps[i].innerText=fToCel(temp);
        }
        else{
            temps[i].innerText=cToFar(temp);
        }
    }
    
}